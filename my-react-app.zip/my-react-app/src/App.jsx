import Hero from './components/Hero';
import FeaturedWork from './components/BodyContent';
import FAQ from './components/FAQ';
import Footer from './components/Footer';
import './index.css';

function App() {
  return (
    <>
      <Hero />
      <FeaturedWork />
      <FAQ />
      <Footer />
    </>
  );
}

export default App;
