function Hero() {
  return (
    <section className="hero">
      <nav>
        <h2>Jhad Osciah Calumpang</h2>
        <ul>
          <li>Home</li>
          <li>About</li>
          <li>Contact</li>
        </ul>
      </nav>
      <div className="hero-content">
        <div>
          <h1>Hello, <span>Bossing Musta Buhay Buhay</span></h1>
          <p>I create immersive gaming experiences that captivate players through engaging stories, innovative gameplay, and striking visuals.
</p>
          <button>Get in Touch</button>
        </div>
        <img src="/src/gaming.png" alt="" />
      </div>
    </section>
  );
}

export default Hero;
