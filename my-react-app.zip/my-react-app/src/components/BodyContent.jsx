function FeaturedWork() {
  return (
    <section className="featured">
      <h2>Featured Work</h2>
      <div className="work-card">
        <img src="/src/yeahhh.webp" alt="" />
        <div>
          <h3>Moba Games</h3>
          <p>MOBA games, or Multiplayer Online Battle Arena games, are a hugely popular and competitive genre where two teams of players, typically five on each side, face off on a symmetrical map with the main objective of destroying the opposing team’s base or “nexus.” Each player controls a unique hero or champion with distinct abilities, and throughout the match, they gain experience and gold by defeating enemy players, minions, and neutral creatures, allowing them to level up and purchase powerful items to strengthen their character. The gameplay revolves heavily around teamwork, strategic decision-making, map control, and timing, as players must coordinate to push lanes, take down defensive towers, secure important objectives like bosses or dragons, and ultimately overwhelm the enemy team. Some of the most famous MOBAs include *League of Legends*, known for its massive global esports scene and constant updates; *Dota 2*, praised for its depth and complexity; and mobile-focused titles like *Mobile Legends: Bang Bang* and *Arena of Valor*, which have brought the MOBA experience to smartphones and expanded the genre’s reach worldwide. Other unique takes on the genre include *Heroes of the Storm* by Blizzard, which features characters from various game universes, and *Smite*, which offers a third-person perspective instead of the traditional top-down view. Whether played on PC, mobile, or consoles, MOBAs demand a blend of mechanical skill, strategic thinking, and teamwork, making them some of the most engaging and enduring multiplayer games in the industry.
</p>
          <button>Learn More</button>
        </div>
      </div>
    </section>
  );
}

export default FeaturedWork;
