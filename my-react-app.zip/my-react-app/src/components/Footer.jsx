function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 Jhad Osciah Gwapo | Follow @JhadGwapoGaming</p>
    </footer>
  );
}

export default Footer;

