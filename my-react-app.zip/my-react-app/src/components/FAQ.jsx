function FAQ() {
  return (
    <section className="faq">
      <h2>FAQ</h2>
      <div className="faq-item">
        <h4>What kind of games do you design?</h4>
        <p>I focus on immersive, story-driven and competitive multiplayer games.</p>
      </div>
      <div className="faq-item">
        <h4>How can I contact you for a project?</h4>
        <p>Click the “Get in Touch” button above to reach out via email or Discord.</p>
      </div>
    </section>
  );
}

export default FAQ;
